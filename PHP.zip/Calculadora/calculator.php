<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Resultado</title>
</head>
<body>
    <div class="calculator">
        <?php
        if(isset($_POST['num1']) && isset($_POST['num2']) && isset($_POST['operator'])){
            $num1 = $_POST['num1'];
            $num2 = $_POST['num2'];
            $operator = $_POST['operator'];
            $result = 0;

            switch($operator){
                case '+':
                    $result = $num1 + $num2;
                    break;
                case '-':
                    $result = $num1 - $num2;
                    break;
                case '*':
                    $result = $num1 * $num2;
                    break;
                case '/':
                    if($num2 != 0){
                        $result = $num1 / $num2;
                    } else {
                        $result = "Error: División por cero";
                    }
                    break;
                case '^':
                    $result = pow($num1, $num2);
                    break;
                case 'sqrt':
                    $result = sqrt($num1);
                    break;
                default:
                    $result = "Operador no válido";
            }

            echo "<h2>Resultado:</h2>";
            echo "<p>$result</p>";
        } else {
            echo "<h2>Error: Por favor, complete todos los campos del formulario.</h2>";
        }
        ?>
        <a href="index.php">Volver</a>
    </div>
</body>
</html>
