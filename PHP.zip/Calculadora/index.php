<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Calculadora</title>
</head>
<body>
    <div class="calculator">
        <form action="calculator.php" method="post">
            <input type="text" name="num1" placeholder="Número 1" required>
            <select name="operator" required>
                <option value="+">Suma</option>
                <option value="-">Resta</option>
                <option value="*">Multiplicación</option>
                <option value="/">División</option>
                <option value="^">Elevación</option>
                <option value="sqrt">Raíz Cuadrada</option>
            </select>
            <input type="text" name="num2" placeholder="Número 2" required>
            <button type="submit">Calcular</button>
        </form>
    </div>
</body>
</html>
