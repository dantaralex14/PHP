<html>
<head>
<title>Ejemplo Pagina 1 Libreria</title>
</head>
<body>
<?php include("21_libreria.phtml") ?>
<?php CabeceraPagina(); ?>
Página 1
<BR><BR><BR><BR><BR>
Contenido blalbl blalb alb<BR><BR>
más cosas...<BR><BR>
fin<BR><BR>
<?php PiePagina(); ?>

</body>
</html>