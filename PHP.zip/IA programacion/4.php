<html>
<head>
<title></title>
</head>
<body>
<h1>Primer ejemplo de Variables </h1>
<p>
<?php
$Name = "Miguel";
echo "Hola <b>$Name</b>, encantado de conocerte";
?>
</p>
</body>
</html>
