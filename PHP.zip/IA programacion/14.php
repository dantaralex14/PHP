<!DOCTYPE html>
<html>
<head>
<title>Calculos </title>
</head>
<body>
<h1>Calculos, redondeo y formato. </h1>
<?php
/* Primero declaramos las variables */
$precioneto = 101.98;
$iva = 0.196;
$resultado = $precioneto * $iva;
echo "El precio es de ";
echo $precioneto;
echo " y el IVA es del ";
echo $iva * 100;
echo "% <br>";
echo "Resultado: " ;
echo round($resultado, 2);
echo " con ROUND() <br>";
echo $resultado;
echo " sin redondeo <br><br>";
$resultado2 = sprintf("%01.2f", $resultado);
echo "Usando la función SPRINTF se ve así: ";
echo $resultado2;
?>
</body>
</html>
