<html>
<head>
<title>Operaciones en PHP</title>
</head>
<body>
<h1>Operaciones en PHP</h1>

<?php
// Operaciones Aritméticas
$numero1 = 20;
$numero2 = 10;
$suma = $numero1 + $numero2;
$resta = $numero1 - $numero2;
$multiplicacion = $numero1 * $numero2;
$division = $numero1 / $numero2;

echo "Resultados de Operaciones Aritméticas:<br>";
echo "Suma: $suma<br>";
echo "Resta: $resta<br>";
echo "Multiplicación: $multiplicacion<br>";
echo "División: $division<br><br>";

// Operaciones de Comparación
$valor1 = 15;
$valor2 = 10;

echo "Resultados de Operaciones de Comparación:<br>";
echo "\$valor1 es igual a \$valor2: " . ($valor1 == $valor2 ? 'true' : 'false') . "<br>";
echo "\$valor1 es diferente de \$valor2: " . ($valor1 != $valor2 ? 'true' : 'false') . "<br>";
echo "\$valor1 es menor que \$valor2: " . ($valor1 < $valor2 ? 'true' : 'false') . "<br>";
echo "\$valor1 es mayor que \$valor2: " . ($valor1 > $valor2 ? 'true' : 'false') . "<br>";
echo "\$valor1 es menor o igual que \$valor2: " . ($valor1 <= $valor2 ? 'true' : 'false') . "<br>";
echo "\$valor1 es mayor o igual que \$valor2: " . ($valor1 >= $valor2 ? 'true' : 'false') . "<br><br>";

// Operaciones Lógicas
$booleano1 = true;
$booleano2 = false;
$booleano3 = true;

echo "Resultados de Operaciones Lógicas:<br>";
echo "\$booleano1 AND \$booleano2: " . ($booleano1 && $booleano2 ? 'true' : 'false') . "<br>";
echo "\$booleano1 OR \$booleano3: " . ($booleano1 || $booleano3 ? 'true' : 'false') . "<br>";
echo "NOT \$booleano2: " . (!$booleano2 ? 'true' : 'false') . "<br><br>";

// Concatenación de Cadenas
$nombre = "Juan";
$apellido = "Pérez";
$nombreCompleto = $nombre . " " . $apellido;

echo "Concatenación de Cadenas:<br>";
echo "Nombre Completo: $nombreCompleto";
?>
</body>
</html>
