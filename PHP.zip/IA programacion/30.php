<html>
<head>
<title>Un libro de visitas muy sencillo</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
</head>
<body>
<h1>Libro de visitas</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
Tu comentario:<br>
<textarea cols="55" rows="4" name="comment"></textarea><br>
Tu nombre:<br>
<input type="text" name="name"><br>
Tu e-mail:<br>
<input type="text" name="email"><br>
<input type="submit" value="publicar">
</form>
<h3>Mostrar todos los comentarios</h3>
<?php
$file = "guestbook.txt";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['comment']) && !empty($_POST['name']) && !empty($_POST['email'])) {
    $comment = $_POST['comment'];
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Abre el archivo en modo escritura-lectura
    $fp = fopen($file, "a+");
    
    if ($fp) {
        // Escapa los caracteres HTML y las comillas simples en el comentario
        $comment = htmlspecialchars($comment, ENT_QUOTES);
        // Crea un enlace de correo electrónico
        $email = "<a href=\"mailto:$email\">$email</a>";
        // Obtiene la fecha actual en el formato deseado
        $dateOfEntry = date("y-n-j");
        // Crea la entrada del libro de visitas
        $entry = "<p><b>$name</b> ($email) escribió el <i>$dateOfEntry</i>:<br>$comment</p>\n";
        // Escribe la entrada en el archivo
        fwrite($fp, $entry);
        // Cierra el archivo
        fclose($fp);
    }
}

// Muestra todos los comentarios almacenados en el archivo
echo file_get_contents($file);
?>
</body>
</html>
