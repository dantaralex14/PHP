<html>
<head>
<title>Condicional Switch</title>
</head>
<body>
<h1>Condicional Switch. Ejemplo</h1>
<?php
/*Declaramos una variable con un valor de muestra */
$posicion = "arriba";
echo "La variable posición es ", $posicion;
echo "<br>";
switch ($posicion) {
    case "arriba": // Primer condición si es arriba
        echo "La variable contiene el valor de arriba";
        break;
    case "abajo": // Segunda condición del supuesto
        echo "La variable contiene el valor de abajo";
        break;
    default: // Condición por defecto o si no es ninguna
        echo "La variable contiene otro valor distinto de arriba y abajo";
}
?>
</body>
</html>
