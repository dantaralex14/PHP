<html>
<head>
<title>EJERCICIO 3_1: ANALISIS DE FORMULARIO</title>
</head>
<body>
<h1>EJERCICIO 3_1: ANALISIS DE FORMULARIO</h1><br>
<br>
<h1>analisis de formularios (analisis.php)</h1>
<?php
echo "Hola <b>{$_POST['firstname']}</b>, encantado de saludarte.";
?>
</body>
</html>