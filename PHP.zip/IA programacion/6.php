<html>
<head>
<title></title>
</head>
<body>
<h1>Break en la ventana del navegador</h1>
<p>
<?php
$Name = "Miguel";
echo "Hola <b>$Name</b>, encantado de conocerte<br>";
echo "Gracias por venir!";
?>
</p>
</body>
</html>
