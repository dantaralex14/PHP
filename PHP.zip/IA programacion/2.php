<html>
<head>
<title>Hola Mundo</title>
</head>
<body>
<h1> El famoso script Hello World</h1>
<p>
<?php
echo "Hola Mundo!";
?>
</p>
</body>
</html>
