<?php
echo "Tabla de multiplicar del 2 usando for:<br>";
for ($f = 2; $f <= 20; $f += 2) {
    echo "2 x $f = " . (2 * $f) . "<br>";
}

echo "Tabla de multiplicar del 2 usando while:<br>";
$f = 2;
while ($f <= 20) {
    echo "2 x $f = " . (2 * $f) . "<br>";
    $f += 2;
}

echo "Tabla de multiplicar del 2 usando do/while:<br>";
$f = 2;
do {
    echo "2 x $f = " . (2 * $f) . "<br>";
    $f += 2;
} while ($f <= 20);
?>