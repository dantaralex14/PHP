<html>
 <head>
<title>Ejemplo de operadores de Comparacion</title>
</head>
<body>
<h1>Ejemplo de operaciones comparacion en PHP</h1>
<?php

$a = 8;
$b = 3;
$c = 3;
echo $a == $b, "<br>";
echo $a != $b, "<br>";
echo $a < $b, "<br>";
echo $a > $b, "<br>";
echo $a >= $c, "<br>";
echo $a <= $c, "<br>";

?>
</body>
</html>