<?php
$integerVariable = 42;
$doubleVariable = 3.14;
$stringVariable = "Hola, mundo!";
$booleanVariable = true;
echo $integerVariable . "<br>";
echo $doubleVariable . "<br>";
echo $stringVariable . "<br>";
echo $booleanVariable . "<br>";
?>
