<html>
<head>
    <title>Introduccion a los arrays, metodo corto</title>
</head>
<body>
    <h1> Introduccion a los arrays, metodo corto </h1>
    <p> A continuacion escribiremos los arrays de acuerdo al metodo corto </p>
    <p>
        <?php
/*
Este es el metodo corto para la creacion de arrays, donde cada todo el array
puede estar en una sola linea de codigo.
*/
$dia = array( "domingo", "lunes", "martes", "miercoles", "jueves", "viernes", "sabado");
//mostrar el miercoles
echo $dia[0];
?>
</p>
</body>
</html>