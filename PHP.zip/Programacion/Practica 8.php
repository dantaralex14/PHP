<?php
$precio = 90;
$año = 2023;
$cantidad = 5;

echo "La computadora tiene un precio de $precio dolares, fue lanzada en el año $año, y tenemos $cantidad unidades en stock.";
?>
