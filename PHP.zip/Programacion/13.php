<!DOCTYPE html>
<html>
<head>
    <title>Operaciones en PHP</title>
</head>
<body>
    <h1>Operaciones en PHP</h1>
    <?php
    $a = 6;
    $b = 9;
    echo "a = $a<br>";
    echo "b = $b<br>";
    echo "Suma: " . ($a + $b) . "<br>";
    echo "Resta: " . ($a - $b) . "<br>";
    echo "Multiplicación: " . ($a * $b) . "<br>";
    echo "División: " . ($a / $b) . "<br>";
    echo "Igual que: " . ($a == $b ? "Sí" : "No") . "<br>";
    echo "Menor o igual que: " . ($a <= $b ? "Sí" : "No") . "<br>";
    ?>
</body>
</html>
