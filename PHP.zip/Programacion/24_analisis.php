<!DOCTYPE html>
<html>
<head>
    <title>EJERCICIO 3_1: ANALISIS DE FORMULARIO</title>
</head>
<body>
<h1>EJERCICIO 3_1: ANALISIS DE FORMULARIO</h1><br>
<br>
<h1>analisis de formularios (analisis.php)</h1>
<?php
if(isset($_POST['firstname'])) {
    $nombre = htmlspecialchars($_POST['firstname'], ENT_QUOTES, 'UTF-8');
    echo "Hola <b>$nombre</b>, encantado de saludarte.";
} else {
    echo "No se recibieron datos del formulario.";
}
?>
</body>
</html>
