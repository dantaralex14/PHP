<html>
<head></head>
<body>
<?php
$num = rand(1,100);
if ($num<=50)
{
echo "$num";
}
if($num>=50)
{
echo "$num";
}
?>
</body>
</html>