<?php
$numeroAleatorio = rand(1, 5);
if ($numeroAleatorio == 1) {
    echo "uno";
} elseif ($numeroAleatorio == 2) {
    echo "dos";
} elseif ($numeroAleatorio == 3) {
    echo "tres";
} elseif ($numeroAleatorio == 4) {
    echo "cuatro";
} elseif ($numeroAleatorio == 5) {
    echo "cinco";
}
?>
