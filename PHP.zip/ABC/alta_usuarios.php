<?php
// Conectar a la base de datos
$conexion = mysqli_connect("localhost", "root", "", "biblioteca") or die("Error al conectar a la base de datos!");
$conexion->set_charset("utf8");

// Verificar si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger los datos del formulario
    $nombre = $_POST["nombre"];
    $password = $_POST["password"];

    // Realizar la inserción en la base de datos
    $query = "INSERT INTO usuarios (nombre, pass) VALUES ('$nombre', '$password')";
    mysqli_query($conexion, $query) or die("Problemas en la inserción:" . mysqli_error($conexion));

    echo "Usuario registrado correctamente";
}

// Cerrar la conexión
mysqli_close($conexion);
?>
