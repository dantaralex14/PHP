<?php
$conexion = mysqli_connect("localhost", "root", "", "biblioteca") or die("Error al conectar a la base de datos!");
$conexion->set_charset("utf8");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo_usuario = $_POST["codigo_usuario"];
    $codigo_libro = $_POST["codigo_libro"];
    $fecha_prestamo = $_POST["fecha_prestamo"];
    $fecha_devolucion = $_POST["fecha_devolucion"];
    $query = "INSERT INTO prestamos (codigo_usuario, codigo_libro, fecha_prestamo, fecha_devolucion) 
              VALUES ('$codigo_usuario', '$codigo_libro', '$fecha_prestamo', '$fecha_devolucion')";
    mysqli_query($conexion, $query) or die("Problemas en la inserción:" . mysqli_error($conexion));
    echo "Préstamo registrado correctamente";
}
mysqli_close($conexion);
?>
