<?php
$conexion = mysqli_connect("localhost", "root", "", "biblioteca") or die("Error al conectar a la base de datos!");
$conexion->set_charset("utf8");

$Nombre_form = isset($_POST['Nombre_form']) ? mysqli_real_escape_string($conexion, $_POST['Nombre_form']) : '';
$Apellidos_form = isset($_POST['Apellidos_form']) ? mysqli_real_escape_string($conexion, $_POST['Apellidos_usr_form']) : '';
$Codigo_usuario_form = isset($_POST['Codigo_usuario_form']) ? $_POST['Codigo_usuario_form'] : '';

if (!empty($nombre_usr_form) && !empty($apellido_usr_form) && !empty($Codigo_usuario_form)) {
    $query = "UPDATE usuarios
              SET Nombre='$Nombre_form', Apellidos='$Apellidos_form'
              WHERE Codigo_usuario=$Codigo_usuario_form";
    mysqli_query($conexion, $query) or die("Problemas en el update:" . mysqli_error($conexion));

    echo "Se modificó el nombre y apellidos del usuario";
} else {
    echo "No se proporcionaron valores válidos para la actualización";
}

echo "<br>";
echo "<a href=\"EjemploBD.php\">inicio</a>";
?>
