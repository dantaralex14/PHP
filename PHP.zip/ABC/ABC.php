    <!DOCTYPE html> 
    <meta charset="UTF-8">

    <?php 

    $con = mysqli_connect("localhost","root","","biblioteca") or die ("Error!"); 

    ?>

    <html>
    <head>
        <title>Aplicacion</title>
        </HEAD><H1><P ALIGN="CENTER"><FONT SIZE="7" COLOR="BLACK" FACE="Tempus Sans ITC"> Altas, Bajas y Consultas</H1><B><B></FONT> <B><B>
        <meta charset="utf-8">
    </head>
    <body BACKGROUND="303.JPG">
    <form method="POST" action="ABC.php">
        <label>Correo:<br></label>
        <input type="text" name="Correo" placeholder = "Escriba su correo"><br />
        <label>Contraseña:<br> </label>
        <input type="password" name="passw" placeholder = "Escriba su contraseña"><br />
        <label>Email:<br></label>
        <input type="text" name="email" placeholder = "Escriba su email"><br /><br>
        <input type="submit" name="insert" value = "INSERTAR DATOS">

    </form>

    <?php
        if (isset($_POST["insert"])) {
            $Codigo_usuario = $_POST["Codigo"];
            $Nombre = $_POST["Nombre"];
            $Apellidos = $_POST["Apellidos"];
            $DNI = $_POST["D.N.I"];
            $Domicilio = $_POST["Domicilio"];
            $Poblacion = $_POST["Poblacion"];
            $Provincia = $_POST["Provincia"];
            $Fecha_nac = $_POST["Fecha_nac"];
        
            $insertar = "INSERT INTO Usuarios (Codigo_usuario, Nombre, Apellidos, DNI, Domicilio, Poblacion, Provincia, Fecha_nac) VALUES ('$Codigo_usuario', '$Nombre', '$Apellidos', '$D.N.I', '$Domicilio', '$Poblacion', '$Provincia', '$Fecha_nac')";
            $ejecutar = mysqli_query($con, $insertar);
        
            if ($ejecutar) {
                echo "<h3>Insertado Correctamente</h3>";
            }
        }
        ?>
    <br/>
    <center><table width="500" border="2" style="background-color: #F9F9F9; ">
        <tr>
            <th>Codigo_usuario</th>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>DNI</th>
            <th>Domicilio</th>
            <th>Poblacion</th>
            <th>Provincia</th>
            <th>Fecha_nac</th>
            <th>Editar</th>
            <th>Borrar</th>
        </tr></center>
        <?php
$consulta = "SELECT * FROM Usuarios";
$ejecutar = mysqli_query($con, $consulta);
$i = 0;
while ($fila = mysqli_fetch_array($ejecutar)) {
    $Codigo_usuario = $fila['Codigo_usuario'];
    $Nombre = $fila['Nombre'];
    $Apellidos = $fila['Apellidos'];
    $DNI = $fila['D.N.I'];
    $Domicilio = $fila['Domicilio'];
    $Poblacion = $fila['Poblacion'];
    $Provincia = $fila['Provincia'];
    $Fecha_nac = $fila['Fecha_nac'];
    $i++;
?>
<tr align="center">
    <td><?php echo $Codigo_usuario; ?></td>
    <td><?php echo $Nombre; ?></td>
    <td><?php echo $Apellidos; ?></td>
    <td><?php echo $DNI; ?></td>
    <td><?php echo $Domicilio; ?></td>
    <td><?php echo $Poblacion; ?></td>
    <td><?php echo $Provincia; ?></td>
    <td><?php echo $Fecha_nac; ?></td>
    <td><a href="ABC.php?editar=<?php echo $Codigo_usuario; ?>">Editar</a></td>
    <td><a href="ABC.php?borrar=<?php echo $Codigo_usuario; ?>">Borrar</a></td>
</tr>
<?php } ?>

<?php
    if(isset($_GET['borrar'])){
        $borrar_id = $_GET['borrar'];
        $borrar = "DELETE FROM registro WHERE id = '$borrar_id'";
        $ejecutar = mysqli_query($con, $borrar);

        if ($ejecutar){
            echo "<script>alert('El usuario ha sido borrado!')</script>";
            echo "<script>windoows.open('ABC.php','_self')</script>";
        }

    }
?>
<br><br><br><br><br>
<MARQUEE DIRECTION="RIGHT" FACE="Arial Unicode MS" BEHAVIOR="ALTERNATE" BGCOLOR ="PINK">
<FONT COLOR="BLACK">
<center> Universidad de Colima <br>
Materia: Programación web <br>
Ingenieria en en computo inteligente</FONT></MARQUEE>
</body>
</html>