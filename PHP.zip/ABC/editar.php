<?php
if (isset($_POST["codEditar"]) && !empty($_POST["codEditar"])) {
    $conexion = mysqli_connect("localhost", "root", "", "biblioteca") or die("Error al conectar a la base de datos!");
    $conexion->set_charset("utf8");
    $codigo_usuario = mysqli_real_escape_string($conexion, $_POST["codEditar"]);
    $consulta = "SELECT * FROM usuarios WHERE Codigo_usuario = $codigo_usuario";
    $registros = mysqli_query($conexion, $consulta) or die("Problemas en el select:" . mysqli_error($conexion));
    if ($reg = mysqli_fetch_array($registros)) {
        ?>
        <form action="modificar.php" method="post">
            Ingrese el nuevo nombre del usuario:
            <input type="text" name="nombre_usr_form" value="<?php echo $reg['nombre'] ?>">
            <input type="text" name="apellido_usr_form" value="<?php echo $reg['apellidos'] ?>">
            <input type="text" name="usr_form" value="<?php echo $reg['nombre'] ?>">
            <input type="text" name="clave_form" value="<?php echo $reg['pass'] ?>">
            <input type="hidden" name="Codigo_usuario_form" value="<?php echo $reg['Codigo_usuario'] ?>">
            <br>
            <input type="submit" value="Modificar">
        </form>
        <?php
    } else {
        echo "No existe un usuario con dicho código";
    }
    mysqli_close($conexion);
} else {
    echo "No se ha proporcionado un código de usuario para editar";
}
?>
