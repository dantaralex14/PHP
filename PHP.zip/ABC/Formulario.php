<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Menú de Biblioteca</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>

<header>
    <div id="menu">
        <ul>
            <li id="logo"><a href="#">Logo</a></li>
            <li><a href="#">Registro de Usuarios</a></li>
            <li><a href="#">Consulta Libre de Libros</a></li>
            <li><a href="#">Iniciar Sesión</a></li>
        </ul>
    </div>
</header>

<main>
    <h1>Menú de Biblioteca</h1>
    <section>
        <h2>Registro de Usuarios</h2>
        <form action="registro_usuarios.php" method="post">
            Nombre:
            <input type="text" name="nombre" maxlength="50"><br>
            Contraseña:
            <input type="password" name="password"><br>
            <input type="submit" name="submit" value="Registrar Usuario">
        </form>
    </section>
    <section>
        <h2>Consulta Libre de Libros</h2>
        <?php
        $conexion = mysqli_connect("localhost", "root", "", "biblioteca") or die("Error al conectar a la base de datos!");
        $consulta_libros = "SELECT * FROM libros";
        $resultado_libros = mysqli_query($conexion, $consulta_libros) or die("Problemas en la consulta:" . mysqli_error($conexion));
        echo "<table border='1'>";
        echo "<tr><th>Codigo del libro</th><th>Título</th><th>Autor</th><th>Editorial</th><th>Genero</th><th>Pais</th><th>Numero de paginas</th><th>Año edicion</th><th>Precio del libro</th></tr>";
        while ($libro = mysqli_fetch_assoc($resultado_libros)) {
            echo "<tr>";
            echo "<td>{$libro['Codigo_libro']}</td>";
            echo "<td>{$libro['Nombre_libro']}</td>";
            echo "<td>{$libro['Editorial']}</td>";
            echo "<td>{$libro['Autor']}</td>";
            echo "<td>{$libro['Genero']}</td>";
            echo "<td>{$libro['Pais_autor']}</td>";
            echo "<td>{$libro['Num_paginas']}</td>";
            echo "<td>{$libro['Año_edicion']}</td>";
            echo "<td>{$libro['Precio_libro']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        mysqli_close($conexion);
        ?>
    </section>

    <section>
        <h2>Iniciar Sesión</h2>
        <form action="iniciar_sesion.php" method="post">
            Usuario:
            <input type="text" name="usuario"><br>
            Contraseña:
            <input type="password" name="contrasena"><br>
            <input type="submit" name="submit" value="Iniciar Sesión">
        </form>
    </section>

    <section>
        <h2>Info</h2>
        <ul>
            <li><a href="alta_usuarios.php">Alta Usuarios</a></li>
            <li><a href="alta_libros.php">Alta Libros</a></li>
            <li><a href="prestamos.php">Prestamos</a></li>
        </ul>
    </section>
</main>

<footer>
    <!-- Contenido del pie de página -->
</footer>

</body>
</html>

