<?php
// Conectar a la base de datos
$conexion = mysqli_connect("localhost", "root", "", "biblioteca") or die("Error al conectar a la base de datos!");
$conexion->set_charset("utf8");

// Verificar si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger los datos del formulario
    // Ajusta estos campos según la estructura de tu tabla "libros"
    $nombre_libro = $_POST["nombre_libro"];
    $editorial = $_POST["editorial"];
    $autor = $_POST["autor"];
    $genero = $_POST["genero"];
    $pais_autor = $_POST["pais_autor"];
    $num_paginas = $_POST["num_paginas"];
    $año_edicion = $_POST["año_edicion"];
    $precio_libro = $_POST["precio_libro"];

    // Realizar la inserción en la base de datos
    $query = "INSERT INTO libros (Nombre_libro, Editorial, Autor, Genero, Pais_autor, Num_paginas, Año_edicion, Precio_libro) 
              VALUES ('$nombre_libro', '$editorial', '$autor', '$genero', '$pais_autor', '$num_paginas', '$año_edicion', '$precio_libro')";
    mysqli_query($conexion, $query) or die("Problemas en la inserción:" . mysqli_error($conexion));

    echo "Libro registrado correctamente";
}

// Cerrar la conexión
mysqli_close($conexion);
?>
