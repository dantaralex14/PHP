<?php
$conexion = mysqli_connect("localhost", "root", "", "biblioteca") or die("Error al conectar a la base de datos!");
$conexion->set_charset("utf8");

if (isset($_REQUEST['Codigo_usuario_form']) && !empty($_REQUEST['Codigo_usuario_form'])) {
    $Codigo_usuario_form = $_REQUEST['Codigo_usuario_form'];

    mysqli_query($conexion, "DELETE FROM usuarios WHERE Codigo_usuario = '$_REQUEST[codEliminar]'") or die("Problemas en el delete:" . mysqli_error($conexion));
    echo "Se eliminó el usuario con dicho código.";
} else {
    echo "No se proporcionó un código de usuario válido para eliminar.";
}

echo "<br>";
echo "<a href=\"EjemploBD.php\">inicio</a>";
?>
