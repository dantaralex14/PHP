<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $usuario = "root";
    $password = "";
    $servidor = "localhost";
    $basededatos = "biblioteca";

    $conexion = mysqli_connect($servidor, $usuario, "", $basededatos) or die ("No se ha podido conectar al servidor de Base de datos");
    $db = mysqli_select_db($conexion, $basededatos) or die ("Upps! Pues va a ser que no se ha podido conectar a la base de datos");

    $consulta = "SELECT * FROM usuarios";
    $resultado = mysqli_query($conexion, $consulta) or die ("Algo ha ido mal en la consulta a la base de datos");
    ?>

    <form method="POST" action="EjemploBD.php">
        <label>Codigo_usuario:<br></label>
        <input type="text" name="Codigo_usuario" placeholder="Escriba su codigo usuario"><br />
        <label>Nombre:<br></label>
        <input type="text" name="Nombre" placeholder="Escriba su nombre"><br />
        <label>Apellidos:<br></label>
        <input type="text" name="Apellidos" placeholder="Escriba su apellido"><br />
        <label>D.N.I:<br></label>
        <input type="text" name="DNI" placeholder="Escriba su D.N.I"><br />
        <label>Domicilio:<br> </label>
        <input type="text" name="Domicilio" placeholder="Escriba su domicilio"><br />
        <label>Poblacion:<br></label>
        <input type="text" name="Poblacion" placeholder="Escriba su poblacion"><br />
        <label>Provincia:<br></label>
        <input type="text" name="Provincia" placeholder="Escriba su provincia"><br />
        <label>Fecha_nac:<br></label>
        <input type="date" name="Fecha_nac" placeholder="Escriba su fecha de nacimiento"><br />
        
        <input type="submit" name="insert" value="INSERTAR DATOS">
    </form>

    <?php
    if(isset($_POST["insert"])){
        $Codigo_usuario = $_POST["Codigo_usuario"];
        $Nombre = $_POST["Nombre"];
        $Apellidos = $_POST["Apellidos"];
        $DNI = $_POST["DNI"];
        $Domicilio = $_POST["Domicilio"];
        $Provincia = $_POST["Provincia"];
        $Fecha_nac = $_POST["Fecha_nac"];

        $insertar = "INSERT INTO usuarios (Codigo_usuario, Nombre, Apellidos, DNI, Domicilio, Provincia, Fecha_nac) VALUES ('$Codigo_usuario', '$Nombre', '$Apellidos', '$DNI', '$Domicilio', '$Provincia', '$Fecha_nac')";
        $ejecutar = mysqli_query($conexion, $insertar);

        if ($ejecutar){
            echo "<h3>Insertado Correctamente</h3>";
        }
    }
    ?>

    <br><br><br>
    Aquí se muestran los resultados de la base de datos.
    <br><br>

    <?php
    echo "<table border='2'>";
    echo "<tr>";
    echo "<th>Codigo_usuario</th>";
    echo "<th>Nombre</th>";
    echo "<th>Apellidos</th>";
    echo "<th>D.N.I</th>";
    echo "<th>Domicilio</th>";
    echo "<th>Provincia</th>";
    echo "<th>Fecha_nac</th>";
    echo "</tr>";

    while ($columna = mysqli_fetch_array($resultado)) {
        echo "<tr>";
        echo "<td>" . (isset($columna['Codigo_usuario']) ? $columna['Codigo_usuario'] : "") . "</td>";
        echo "<td>" . (isset($columna['Nombre']) ? $columna['Nombre'] : "") . "</td>";
        echo "<td>" . (isset($columna['Apellidos']) ? $columna['Apellidos'] : "") . "</td>";
        echo "<td>" . (isset($columna['D.N.I']) ? $columna['D.N.I'] : "") . "</td>";
        echo "<td>" . (isset($columna['Domicilio']) ? $columna['Domicilio'] : "") . "</td>";
        echo "<td>" . (isset($columna['Provincia']) ? $columna['Provincia'] : "") . "</td>";
        echo "<td>" . (isset($columna['Fecha_nac']) ? $columna['Fecha_nac'] : "") . "</td>";
        echo "<td> 
    <form method ='POST' action='baja.php'> <input type ='hidden' value='{$columna['Codigo_usuario']}' name='Codigo_usuario_form' /> <input type='submit' value='Eliminar' /> </form> </td>";
    echo "<td> 
    <form method ='POST' action='editar.php'> <input type ='hidden' value='{$columna['Codigo_usuario']}' name='codEditar' /> <input type='submit' value='Modificar' /> </form> </td>";

    }
    
    echo "</table>";

    mysqli_close($conexion);
    ?>
</body>
</html>
